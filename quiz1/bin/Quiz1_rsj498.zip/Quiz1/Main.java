package Quiz1;

//Main.java
/* 
* EE422C Quiz 1 submission by
* Rebecca Jiang
* rsj498
* 
*  Fall 2016

*/
public class Main {
	public static void main(String[] args){
		HelloWorld.hello();
	}
}
