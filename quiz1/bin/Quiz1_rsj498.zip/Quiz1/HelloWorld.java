package Quiz1;

//HelloWorld.java
/* 
* EE422C Quiz 1 submission by
* Rebecca Jiang
* rsj498
* 
*  Fall 2016

*/
public class HelloWorld {

	public static void hello(){
		System.out.println("Hello World");
	}
	
}